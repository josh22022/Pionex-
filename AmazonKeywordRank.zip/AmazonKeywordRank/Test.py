from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.keys import Keys
import pandas as pd
import os
import time
file_path = "C:\AMZ外掛\ReadyToRank"
file_list = os.listdir(file_path)
download_path = "C:\AMZ外掛\Download"
download_list = os.listdir(download_path)
preSort_path = "C:\AMZ外掛\preSort"
preSort_list = os.listdir(preSort_path)
country_ls = ['com','ca','co.jp','co.uk','fr','it','de','es','in','com.mx','com.au']
error = []

def AMZ():
    for i in range(len(file_list)):
        df = pd.read_csv(file_path+'\\'+file_list[i])
        if len(df) <= 200 :
            for j in range(len(df.columns)):
                chrome_options = Options()
                chrome_options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
                chrome_driver = "chromedriver.exe"
                driver = webdriver.Chrome(chrome_driver, chrome_options=chrome_options)
                print(driver.title)
                if df.columns[j] in country_ls:
                    e1 = Select(driver.find_element_by_id("country"))
                    e1.select_by_value(df.columns[j])
                    time.sleep(1)
                    e2 = driver.find_element_by_id('asin')
                    e2.clear()
                    e2.send_keys(str(file_list[i])[0:10])
                    time.sleep(1)
                    e3 = driver.find_element_by_id('keywords')
                    e3.clear()
                    for k in range(len(df)):
                        if type(df.iat[k,j]) == str:
                            e3.send_keys(df.iat[k,j])
                            e3.send_keys(Keys.ENTER)
                        else :
                            break
                    time.sleep(1)
                    e4 = driver.find_element_by_id('search-btn')
                    e4.click()
                    time.sleep(1) #等候秒數
                    e5 = driver.find_element_by_id('progress-bar-text')
                    while True:
                        if e5.text == "Finished!":
                            e6 = driver.find_element_by_xpath('//*[@id="datatable_wrapper"]/div[1]/button[2]/span')
                            e6.click()
                            print(e5.text)
                            time.sleep(5)
                            os.rename(download_path+'\\'+str(file_list[i])[0:10]+'.csv',download_path+'\\'+str(file_list[i])[0:-4]+'_'+str(df.columns[j])+'.csv' )
                            break
                        else:
                            print("Still ranking...",e5.text)
                            time.sleep(3)
                else:
                    print(file_list[i]+" 檔案內容錯誤")
                    error.append(file_list[i])
        else:
            print(file_list[i]+" 關鍵字超過上限")
            error.append(file_list[i])
    for i in range(len(error)):
        print(error[i]+" 沒有執行")
        
def preSort():
    ds = pd.read_csv(download_path+'\\'+download_list[0])
    ds = ds[["Keyword","Rank","Position"]]
    ds.to_csv(preSort_path+'\\'+download_list[0])
    time.sleep(3)
    if os.path.isfile('C:/AMZ外掛/preSort/'+download_list[0]):
      os.remove(download_path+'\\'+download_list[0])
    
            
            
