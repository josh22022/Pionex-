from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.keys import Keys
import pandas as pd
import os
import time
file_path = "C:\AMZ外掛\ReadyToRank"
file_list = os.listdir(file_path)
download_path = "C:\AMZ外掛\Download"
download_list = os.listdir(download_path)
preSort_path = "C:\AMZ外掛\preSort"
preSort_list = os.listdir(preSort_path)
country_ls = ['com','ca','co.jp','co.uk','fr','it','de','es','in','com.mx','com.au']
error = []
        
ds = pd.read_csv(download_path+'\\'+download_list[0])
ds = ds[["Keyword","Rank","Position"]]
ds.to_csv('C:/AMZ外掛/preSort/'+download_list[0])
time.sleep(3)
if os.path.isfile('C:/AMZ外掛/preSort/'+download_list[0]):
  os.remove('C:/AMZ外掛/download/'+download_list[0])
else:
  print("檔案不存在。")